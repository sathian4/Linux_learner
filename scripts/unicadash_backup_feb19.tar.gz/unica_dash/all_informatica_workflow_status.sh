#/bin/bash

curl -s "http://172.16.0.63/dwh_dashboard_newuat/unicaprocess_UAT.php" -o /tmp/all_informatica_status.out


for bid in  1 2 3 4 7 8 9 10 11 12 ; do 

status="`cat /tmp/all_informatica_status.out | sed -n -e "/<td>$bid<\/td>/,/<\/tr>/ p" | grep "<td class=" | grep -v SYNC | cut -d '"' -f2`"

if [ "$status" == "Finished" ]; then script_name="`cat /tmp/all_informatica_status.out | sed -n -e "/<td>$bid<\/td>/,/<\/tr>/ p" | grep  '<td><li><a href="'| cut -d '>' -f4 | cut -d '<' -f1`" ; echo "$script_name - Completed" ; fi

done
