


/bin/bash /home/sakthi/unica_dash/testalert.sh -a "Long_Running_UAT_1AM" -c "Mailer alert" -s Long_Running -d "{ \"Message\": \"Long Running - ${workflow_name}\"}"
