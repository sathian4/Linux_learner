#!/usr/bin/python
import subprocess



subprocess.call("ls -ltra ~/Downloads",shell=True)

