echo $1_$2_$3_$4 >dinesh_1.tst
