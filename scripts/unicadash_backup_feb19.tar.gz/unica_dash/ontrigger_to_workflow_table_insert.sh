#!/bin/bash


if [ $# -eq 3 ]; then 

types="$1"
period="$2"
version="$3"
types="`echo $types | tr [:upper:] [:lower:]`"
> /tmp/${version}_${types}_${period}.sql

MYSQL_PWD='root@123' mysql -uroot -N -s  unica_dashbrd -e "select successfull_trigger from workflow_trigger_dtls where period='$period' and type='$types' and successfull_trigger not in (select workflow_name from unica_${version}_${types}_wf where period='$period') group by successfull_trigger;" | sed "s#^#insert into unica_${version}_${types}_wf (workflow_name,category,status,period,alert) values (\'#g;s#\$#\',\'SYNC\',1,\'${period}\',1);#g" > /tmp/${version}_${types}_${period}.sql 

if [ -s /tmp/${version}_${types}_${period}.sql ]; then cat /tmp/${version}_${types}_${period}.sql 

echo -en "Shall we execute the above query in mysql [yes/no] : "
read yesno

if [ "${yesno}" == "yes" ]; then 
mysql -uroot -proot@123 -vv unica_dashbrd < /tmp/${version}_${types}_${period}.sql > /tmp/${version}_${types}_${period}.out; else echo "Script Exited"; exit ; fi

echo -e "Please check the log file in /tmp/${version}_${types}_${period}.out"

else echo -e "There is no triggers need to insert for Unica $version $types $period\nPlease check...."

fi

else 

echo -e "Please Execute the Script as below\nsh $0 uat 1am v11"

fi

