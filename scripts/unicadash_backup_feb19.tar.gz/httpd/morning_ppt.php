<html !DOCTYPE>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "50";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>
<div class="row">
<div class="column">
<form action="dashboard.php" method="post">
<input type="submit"  value="DashBoard">
</div>
</form>
<div class="column">
<form action="" method="post">
<input type="submit" name="refresh" value="Refresh">
</div>
</form>

<br>
<br>
<br>

<?php
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/morning_ppt_script.sh");
echo "<pre>$output</pre>";    
//if (isset($_POST['refreshs'])) {
//$output=shell_exec("/bin/bash /home/sakthi/unica_dash/morning_ppt_script.sh");
//echo "<pre>$output</pre>";
//}
?>

</body>
</html>

