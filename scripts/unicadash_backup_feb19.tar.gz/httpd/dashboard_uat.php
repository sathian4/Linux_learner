<html !DOCTYPE>
<title >
Unica Dashboard
</title>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  color: black;
}
.column {
  float: left;
  width: "50";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}

</style>
</head>



<body>

<div class="row">
<div class="column">
<form action="/" method="post">
<input type="submit" name="home_page" value="Home Page">
</div>
</form>
<div class="column">
<form action="csv_report_export.php" method="post">
<input type="submit" name="reports" value="Reports">
</div>
</form>
<div class="column">
<form action="status.html" method="post">
<input type="submit" name="status" value="All Unica Status">
</div>
</form>
<div class="column"> 
<form action="stats.php" method="post"> 
<input type="submit" name="stats" value="Statistics"> 
</div> 
</form> 
<div class="column">
<form action="alert_disable.php" method="post">
<input type="submit" name="alert_disable" value="Disable Workflow Alert">
</div>
</form>
<div class="column">
<form action="alert_enable.php" method="post">
<input type="submit" name="alert_enable" value="Enable Workflow Alert">
</div>
</form>
<div class="column">
<form action="morning_ppt.php" method="post">
<input type="submit" name="dwh20" value="DWH 2.0 Count">
</div>
</form>
<div class="row">
<div class="column">
<form action="alert_disabled_list.php" method="post">
<input type="submit" name="alert_disabled_list" value="Alert Disabled List">
</div>
</form>
<br>
<br>
<br>




<?php
$page = $_SERVER['PHP_SELF'];
//$sec = "10";
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step4_uat_for_alert_dashboard.sh");
echo "<pre>$output</pre>";
?>
<html>
    <head>
    <meta http-equiv="refresh" content="<?php echo 10?>;URL='<?php echo $page?>'">

    </head>
    <body>
<?php
//$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step4_for_alert_dashboard.sh");
//echo "<pre>$output</pre>";

?>

<?        if (isset($_POST['home_page'])) {
header("Location: http://192.168.0.60/");
}
header("Cache-Control: no-cache, must-revalidate");
//header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");


?>

    </body>
</html>


