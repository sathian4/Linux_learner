<html !DOCTYPE>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "50";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}

</style>
</head>
<body>


<div class="row">
<div class="column">
<form action="#" method="post">
Start Date: <input type="date" name="sdte" value="<?php echo (isset($_POST['sdte']))?$_POST['sdte']:''; ?>">
<input type="submit" name="date_query" value="Select Start Date" value="Select">
End Date: <input type="date" name="edte" value="<?php echo (isset($_POST['edte']))?$_POST['edte']:''; ?>"> 
<input type="submit" name="date_query" value="Select End Date" value="Select"><br><br>
<div class="column">
<center><h3>Please Click Below Button for Download CSV</h3></center>
<input type="submit" name="1am_uat" value="1AM UAT">
<input type="submit" name="1am_prod" value="1AM PROD">
<input type="submit" name="1pm_uat" value="1PM UAT">
<input type="submit" name="1pm_prod" value="1PM PROD">
<input type="submit" name="7pm_uat" value="7PM UAT">
<form action="index.html" method="post">
<input type="submit" name="home_page" value="Home Page">
<center><h5>Note: Specific date range should have equal workflow names and counts<br>else the report output will be collapsed</h5></center>
</form>
</div>

<br>
<br>
<br>
<br>
<br>
<br>



<div class="column">
<form action="" method="post">
<input type="hidden" name="sdte" value="<?php echo (isset($_POST['sdte']))?$_POST['sdte']:''; ?>">
<input type="hidden" name="edte" value="<?php echo (isset($_POST['edte']))?$_POST['edte']:''; ?>">
<input type="hidden" name="periods" value="<?php echo (isset($_POST['periods']))?$_POST['periods']:''; ?>">
<input type="hidden" name="testss" value="<?php echo (isset($_POST['testss']))?$_POST['testss']:''; ?>">

<a href="output.xls" id="fileDownload" download="unica.xls" style="display:none;">Download</a>
</div>


<?php






$sdt = $_POST["sdte"];
$edt = $_POST["edte"];
$typ = $_POST["testss"];
$prd = $_POST["periods"];



if (isset($_POST['1am_uat'])) {
shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export.sh uat 1am v11 $sdt $edt");
?>
<script type="text/javascript">
var link = document.getElementById('fileDownload');
link.click();
</script>
<?php
}
    elseif (isset($_POST['1am_prod'])) {
shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export.sh prod 1am v11 $sdt $edt");
?>
<script type="text/javascript">
var link = document.getElementById('fileDownload');
link.click();
</script>
<?php
}
	elseif (isset($_POST['1pm_uat'])) {
shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export.sh uat 1pm v11 $sdt $edt");
?>
<script type="text/javascript">
var link = document.getElementById('fileDownload');
link.click();
</script>
<?php
}
	elseif (isset($_POST['1pm_prod'])) {
shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export.sh prod 1pm v11 $sdt $edt");
?>
<script type="text/javascript">
var link = document.getElementById('fileDownload');
link.click();
</script>
<?php
}
	elseif (isset($_POST['7pm_uat'])) {
shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export.sh uat 7pm v11 $sdt $edt");
?>
<script type="text/javascript">
var link = document.getElementById('fileDownload');
link.click();
</script>
<?php
}
	elseif (isset($_POST['home_page'])) {
header("Location: http://192.168.0.60/index.html");
}
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");


?>





</body>
</html>

