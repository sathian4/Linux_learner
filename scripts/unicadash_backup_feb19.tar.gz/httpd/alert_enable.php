<!DOCTYPE html>
<html>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "50";
  padding: 5px;
                  
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}

</style>
</head>
<body>
<div class="column">
<form action="" method="post">
<select name="type" id="type">
<option value="v11_prod">V11_PROD</option>
<option value="v11_uat">V11_UAT</option>
</select>
<button type="button" onclick="myFunction()">Type</button>
<p id="type"></p>

<script>
function myFunction() {
  var x = document.getElementById("mySelect").value;
  document.getElementById("demo").innerHTML = x;
}
</script>


</div>
<div class="column">
<select name="period" id="period">
<option value="">select</option>
<option value="1am">1AM</option>
<option value="1pm">1PM</option>
<option value="7pm">7PM</option>
</select>

<button type="button" onclick="myFunction()">Period</button>
<!--<p id="period"></p>-->

<script>
function myFunction() {
  var x = document.getElementById("mySelect").value;
  document.getElementById("period").innerHTML = x;
}
</script>
</div>


<div class="column">

<select name="WorkFlow" class="workflow">

<?php
$servername = "localhost";
$username = "root";
$password = "root@123";
$dbname = "unica_dashbrd";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$types = $_POST["type"];
$periods = $_POST["period"]; 
$workflow_name = $_POST["Enable_Alert"];

    if (isset($_POST['test'])) {
$output=shell_exec("sh /home/sakthi/unica_dash/enable_alert_script.sh $periods $types $workflow_name");
echo "<pre>$output</pre>";
    }


$sql = "SELECT workflow_name from unica_v11_prod_wf";
$result = $conn->query($sql);
//echo '<select name="DROP DOWN NAME">';
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["workflow_name"]. "<br>";
	echo '<option value="'.$row['workflow_name'].'">'.$row['workflow_name'].'</option>';    

}
};
//echo '</select>';
$conn->close();
?>

</select> 
<button type="submit" name="submit">Enable_Alert</button>
</form>
<p id="Enable_Alert"></p>

<script>
function myFunction() {
  var x = document.getElementById("mySelect").value;
  document.getElementById("WorkFlow").innerHTML = x;
}
</script>
<?php
if(isset($_POST["submit"])){
	$types = isset($_POST["type"])? $_POST["type"] : "";
	$periods = isset($_POST["period"])? $_POST["period"] : "";
	$workflow_name = isset($_POST["WorkFlow"])? $_POST["WorkFlow"] : "";
	$output=shell_exec("sh /home/sakthi/unica_dash/enable_alert_script.sh $periods $types $workflow_name");
	echo "<pre>$output</pre>";
}
?>
<script src="localjs.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
	$("#period").change(function() {
		var period = $(this).val();
		var type = $("#type").val();
		$(".workflow").empty();
		$.ajax({
			type : "POST",
			url : "getworkflow_enable.php",
			data : {period : period, type: type},
			success : function(response) {
				// alert(response);
				if(response == 'no_record'){
					$(".workflow").empty();
				}else{
					$(".workflow").append(response);	
				}
			}
		});
	});
});
</script>
