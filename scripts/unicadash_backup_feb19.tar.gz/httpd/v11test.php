<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "70";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}


</style>
</head>
<body>
<form action="#" method="post">
Previous Date: <input type="date" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>"><br>
<input type="submit" name="date_query" value="Select" value="Select"> 
</form>
<div class="row">
<div class="column">
<form action="" method="post">
<input type="submit" name="current_status" value="Current Status">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="completed_status" value="Completed Status">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</div>
</form>
<div class="column">
<form action="" method="post">
<input type="submit" name="running" value="Running Status">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="not_started" value="Not Started">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="error" value="Error">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="home_page" value="Back">
</form>
</div>
<?php
$dt = $_POST["dte"];
    if (isset($_POST['current_status'])) {
$output=shell_exec("sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 2 1 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['completed_status'])) {
$output=shell_exec("sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 2 2 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['running'])) {
$output=shell_exec('sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 2 3');
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['not_started'])) {
$output=shell_exec('sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 2 4');
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['error'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 2 5");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['home_page'])) {
header("Location: http://192.168.0.60/v11uat_time.php");
    }
    elseif (isset($_POST['date_query'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 2 1 $dt");
echo "<pre>$output</pre>";
    }
?>
</body>
</html>

