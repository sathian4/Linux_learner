<?php
$con = mysql_connect("localhost","admin","admin@123");
 $db = mysql_select_db("unica_dashbrd",$con);
 $get=mysql_query("SELECT workflow_name FROM unica_v11_uat_wf");
$option = '';
 while($row = mysql_fetch_assoc($get))
{
  $option .= '<option value = "'.$row['workflow_name'].'">'.$row['workflow_name'].'</option>';
}
?>
<html>
<body>
test
<form>
<select>
<?php echo $option; ?>
</select>
</form>
</body>
</html>
