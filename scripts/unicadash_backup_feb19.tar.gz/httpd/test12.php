<html !DOCTYPE>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "50";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}

</style>
</head>
<body>


</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="completed_status" value="Completed Status">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</div>
</form>
<div class="column">
<form action="" method="post">
<input type="submit" name="running" value="Running Status">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="not_started" value="Not Started">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="error" value="Error">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="long_running" value="Long Running">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="not_yet_started" value="Not Yet Started">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="home_page" value="Dashboard">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="count_check" value="Count Details">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<form action="#" method="post">
 <select name="period">
  <option value="1am">1AM</option>
  <option value="1pm">1PM</option>
  <option value="7pm">7PM</option>
</select> 
<input type="hidden" name="Unica" value="<?php echo (isset($_POST['period']))?$_POST['period']:''; ?>">
<input type="hidden" name="unica" name="test" value="<?php echo (isset($_POST['unica_type']))?$_POST['unica_type']:''; ?>">
<input type="submit" name="periods" name="test asdfa" value="Period<?php (isset($_POST['unica_type']))?$_POST['unica_type']:''; ?>">
</form>

</div>
<form action="#" method="post">
 <select name="unica_type">
  <option value="uat">UAT</option>
  <option value="prod">PROD</option>
  <option value="7pm">7PM</option>
</select>
<input type="hidden" name="unica" value="<?php echo (isset($_POST['unica_type']))?$_POST['unica_type']:''; ?>">
<input type="hidden" name="Unica" value="<?php echo (isset($_POST['period']))?$_POST['period']:''; ?>">
<input type="submit" name="unica_types" value="Unica Type<?php (isset($_POST['unica_type']))?$_POST['unica_type']:''; ?>">
</form>



<?php
$uversion = $_POST["unica_version"];
    if (isset($_POST['unica_versions'])) {
$output=shell_exec("sh /home/sakthi/unica_dash/test.sh 7 1 $uversion");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['completed_status'])) {
$output=shell_exec("sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 7 2 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['running'])) {
$output=shell_exec("sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 7 3 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['not_started'])) {
$output=shell_exec("sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 7 4 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['error'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 7 5 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['long_running'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 7 6 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['not_yet_started'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 7 7 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['home_page'])) {
header("Location: http://192.168.0.60/dashboard.php");    
}
    elseif (isset($_POST['date_query'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 7 1 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['count_check'])) {
shell_exec("/bin/bash /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 7 1 $dt");
$output=shell_exec("cat /home/sakthi/httpd/count_check.txt");
echo "<pre>$output</pre>";
    }

?>
</body>
</html>

