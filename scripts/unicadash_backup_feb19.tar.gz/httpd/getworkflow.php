<?php
$servername = "localhost";
$username = "root";
$password = "root@123";
$dbname = "unica_dashbrd";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST["type"]) && $_POST["type"] !=''){
	$types = $_POST["type"];
	$periods = $_POST["period"];
	if($types == "v11_uat"){
		$table_name = "unica_v11_uat_wf";		
	}else if($types == "v11_prod"){
		$table_name = "unica_v11_prod_wf";
	}
	echo $sql = "SELECT workflow_name from $table_name where period = '$periods' and status = 1 and alert = 1 order by workflow_name";
	$result = $conn->query($sql);
	// echo '<select name="WorkFlow">';
	if ($result->num_rows > 0) {
    // output data of each row	
		while($row = $result->fetch_assoc()) {        
			echo '<option value="'.$row['workflow_name'].'">'.$row['workflow_name'].'</option>';
		}
	}else{
		echo "no_record";
	}
	// echo '</select>';
}
$conn->close();
?>
