<html>
<title >
UNICA NEW DASHBOARD
</title>
<head>
<style>
.button {
  1d
  border: none;
  color: black;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  button-align: center;	
  display: inline;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.blink_me {
  animation: blinker 2s linear infinite;
}

@keyframes blinker {
  50% {
    opacity: 0;
  }
}
.marquee {
    position: absolute;
    white-space: nowrap;
    -webkit-animation: rightThenLeft 4s linear;
}

@-webkit-keyframes rightThenLeft {
    0%   {left: 0%;}
    50%  {left: 100%;}
    100% {left: 0%;}
}
</style>
<h1><CENTER><big><font face="Times New Roman Bold" color="orange" class="blink_me">UNICA DASHBOARD</font></big></CENTER></h1>
<body background="linux.jpg">

</head>
<br>
<br>
<br>
<br>
<br>
<body>
	<meta charset="UTF-8">
<a href="inford.html" class="button">INFO</a>
<a href="empty.html" class="button">CURRENT STATUS</a>
<a href="empty.html" class="button">REPORTS</a>
<a href="unicadocuments.html" class="button">UNICADOCUMENT</a>
<a href="step3_exec_cur_status.sh" class="button">Status</a>

<?php
 if(isset($_POST['current_status']))
 {
   $output=shell_exec('sh /home/sakthi/acer6_dash/step3_exec_cur_status.sh');
   echo $output;
  }
?>

<form action="" method="post">
<input type="submit" name="current_status" value="Current Status">
</form>

<?php
if ($_GET['run']) {
  # This code will run if ?run=true is set.
  exec("/home/sakthi/acer6_dash/step3_exec_cur_status.sh");
}
?>

<!-- This link will add ?run=true to your URL, myfilename.php?run=true -->
<a href="?run=true">Click Me!</a>
</body>
</HTML>
