<style>
table {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
</style>
<form action="" method="post">
<input type="submit" name="current_status" value="Current Status">
</form>


<?php
$servername = "192.168.0.60";
$username = "root";
$password = "root@123";

// Create connection
$conn = new mysql($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
$output=shell_exec('sh /home/sakthi/acer6_dash/step3_exec_cur_status.sh');
print_r($output);
echo "<pre>$output</pre>";
?>


