 <html>
<body>

<?php 
$dt = $_POST["name"];
echo "<br>";
$out = shell_exec("/bin/bash /home/sakthi/httpd/fullpath.sh 1 2 $dt");
echo $out ;
?>


<br>

</body>
</html>


