Open the config.php file and enter the mysql database user id password and db name. 
Use the sql_dump.txt file to create tables and to populate the records.
Keep all the files in one directory and open the dd3.php file from any location accessed by your server path. 


Use the contact us page at www.plus2net.com to reach us. 

This is downloaded from www.plus2net.com 
  Please don't  remove the link to www.plus2net.com 
 This is for your learning only not for commercial use. 
The author is not responsible for any type of loss or problem or damage on using this script.
You can use it at your own risk.
