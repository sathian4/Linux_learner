<html !DOCTYPE>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  background-color: #4CAF50;  
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "50";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}

</style>
</head>
<body>
<form action="#" method="post">
Previous Date: <input type="date" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>"><br>
<input type="submit" name="date_query" value="Select" value="Select"> 
</form>
<div class="row">
<div class="column">
<form action="" method="post">
<input type="submit" name="home_page" value="Home Page">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="informatica_stats" value="Informatica / Unica Stats">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="error_stats" value="Run Failed Stats">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="longrunning_stats" value="Long Running Stats">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="notyetstarted_stats" value="Not Yet Started Stats">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="trigger_not_completed_stats" value="Trigger Not Completed">
<input type="hidden" name="dte" value="<?php echo (isset($_POST['dte']))?$_POST['dte']:''; ?>">
</form>
</div>
<div class="column">
<form action="dashboard.php" method="post">
<input type="submit"  value="DashBoard">
</div>
</form>



<?php
$dt = $_POST["dte"];
    if (isset($_POST['error_stats'])) {

$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step7_err_longrunning_consolidated_details.sh 3 $dt");
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['home_page'])) {
header("Location: http://192.168.0.60/");
}
    elseif (isset($_POST['informatica_stats'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step7_err_longrunning_consolidated_details.sh 4 $dt");
echo "<pre>$output</pre>";
}
    elseif (isset($_POST['longrunning_stats'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step7_err_longrunning_consolidated_details.sh 1 $dt");
echo "<pre>$output</pre>";
}

    elseif (isset($_POST['notyetstarted_stats'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step7_err_longrunning_consolidated_details.sh 2 $dt");
echo "<pre>$output</pre>";
}

    elseif (isset($_POST['trigger_not_completed_stats'])) {
$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step7_err_longrunning_consolidated_details.sh 5 $dt");
echo "<pre>$output</pre>";
}

?>
</body>
</html>

