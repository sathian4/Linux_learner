<html !DOCTYPE>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "50";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}

</style>
</head>


<html>
<title >
Unica Dashboard
</title>
<head>
<style>
.button {
  background-color: #4CAF50;
  border: none;
  color: black;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  button-align: center;	
  display: inline;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.buttondash {
  background-color: #2517f9;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  button-align: center;
  display: inline;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.blink_me {
  animation: blinker 2s linear infinite;
}

@keyframes blinker {
  50% {
    opacity: 0;
  }
}
.marquee {
    position: absolute;
    white-space: nowrap;
    -webkit-animation: rightThenLeft 4s linear;
}

@-webkit-keyframes rightThenLeft {
    0%   {left: 0%;}
    50%  {left: 100%;}
    100% {left: 0%;}
}
</style>
<h1><CENTER><big><font face="Times New Roman Bold" color="red"><u>UNICA DASHBOARD</u></font></big></CENTER></h1>

</head>
<br>
<br>
<br>
<br>
<br>
<body>
	<meta charset="UTF-8">
<a href="status.html" class="button">ALL UNICA STATUS</a>
<a href="csv_report_export.php" class="button">REPORTS</a>
<a href="unicadocuments.html" class="button">UNICA MAINTENANCE STEPS</a>
<a href="stats.php" class="button">Long_Running & Error STATISTICS</a>
<a href="documents.php" class="button">UNICA DOCUMENTS</a>
<br>
<br>
<br>
<br>
<br>
<br>


<center><body style="background-color:powderblack;"><a href="dashboard.php" class="buttondash">UNICA Currently Running Dashboard</a>

</body>
</HTML>
