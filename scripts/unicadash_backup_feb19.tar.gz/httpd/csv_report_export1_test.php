<html !DOCTYPE>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
</head>
<body>


<form action="#" method="post">
Start Date: <input type="date" name="sdte" value="<?php echo (isset($_POST['sdte']))?$_POST['sdte']:''; ?>">
<input type="submit" name="date_query" value="Select Start Date" value="Select">
End Date: <input type="date" name="edte" value="<?php echo (isset($_POST['edte']))?$_POST['edte']:''; ?>"> 
<input type="submit" name="date_query" value="Select End Date" value="Select"><br><br>
</form>
<form action="#" method="post">
  <select name="periods">
    <option value="1am">1am</option>
    <option value="1pm">1pm</option>
    <option value="7pm">7pm</option>
  </select>
  <input type="submit" value="Period" value="Select">
</form>
<form action="#" method="post">
  <select name="testss">
    <option value="prod">prod</option>
    <option value="uat">uat</option>
  </select>
  <input type="submit" value="Typeasdfs" value="Select">
</form>

<br>
<br>
<br>
<br>
<br>
<br>



<div class="column">
<form action="" method="post">
<input type="submit" name="download_csv" value="Download CSV File">
<input type="hidden" name="sdte" value="<?php echo (isset($_POST['sdte']))?$_POST['sdte']:''; ?>">
<input type="hidden" name="edte" value="<?php echo (isset($_POST['edte']))?$_POST['edte']:''; ?>">
<input type="hidden" name="periods" value="<?php echo (isset($_POST['periods']))?$_POST['periods']:''; ?>">
<input type="hidden" name="testss" value="<?php echo (isset($_POST['testss']))?$_POST['testss']:''; ?>">

<a href="output.csv" id="fileDownload" download="typ_prd.csv" style="display:none;">Download</a>
</div>


<?php
$sdt = $_POST["sdte"];
$edt = $_POST["edte"];
$typ = $_POST["testss"];
$prd = $_POST["periods"];


    if (isset($_POST['download_csv'])) {
shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export.sh $typ $prd $sdt $edt");
?>
<script type="text/javascript">
var link = document.getElementById('fileDownload');
link.click();
</script>
<?php
    }
?>
</body>
</html>

