mysql -uroot -proot@123 -H -e 'select * from sakthi.tbl_datamove_conf;' > /home/sakthi/httpd/current_status.html
