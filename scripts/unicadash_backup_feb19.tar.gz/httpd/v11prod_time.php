<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "70";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}


</style>

<div class="row">
<div class="column">
<form action="v11prod_1am.php" method="post">
<input type="submit"  value="V11 Prod 1AM">
</form>
</div>
<div class="column">
<form action="v11prod_1pm.php" method="post">
<input type="submit"  value="V11 Prod 1PM">
</div>
</form>
<div class="column">
<form action="status.html" method="post">
<input type="submit"  value="Back">
</div>
</form>
<div class="column">
<form action="/" method="post">
<input type="submit"  value="Back HomePage">
</div>
</form>

<table align="right">
  <tr>


