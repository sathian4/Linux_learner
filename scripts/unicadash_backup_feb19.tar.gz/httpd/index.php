<?php 
    // Include the database config file 
    include_once 'dbConfig.php'; 
//$test='1PM'     
    // Fetch all the country data 
    $query = "select * from unica_v11_uat_wf where period='7PM' limit 10"; 
    $result = $db->query($query); 
?>

<!-- Country dropdown -->
<select id="workflow_name">
    <option value="">Select Country</option>
    <?php 
    if($result->num_rows > 0){ 
        while($row = $result->fetch_assoc()){  
            echo '<option value="'.$row['workflow_name'].'">'.$row['workflow_name'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">Country not available</option>'; 
    } 
    ?>
</select>

<!-- State dropdown -->
<select id="state">
    <option value="">Select country first</option>
</select>

<!-- City dropdown -->
<select id="city">
    <option value="">Select state first</option>
</select>
