<html !DOCTYPE>
<head>
<link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Akronim' rel='stylesheet'>
<style>
table {
  font-family: 'Acme', Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td, table th {
  font-family: 'Akronim'	
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  1d
  color: black;
}
.column {
  float: left;
  width: "50";
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}

</style>
</head>
<body>


<div class="row">
<div class="column">
<form action="#" method="post">
Start Date: <input type="date" name="sdte" value="<?php echo (isset($_POST['sdte']))?$_POST['sdte']:''; ?>">
<input type="submit" name="date_query" value="Select Start Date" value="Select">
End Date: <input type="date" name="edte" value="<?php echo (isset($_POST['edte']))?$_POST['edte']:''; ?>"> 
<input type="submit" name="date_query" value="Select End Date" value="Select">
</form>
</div>

<br>
<br>
<br>
<br>
<br>
<br>



<div class="column">
<form action="" method="post">
<input type="submit" name="download_csv" value="Download CSV File">
<input type="hidden" name="sdte" value="<?php echo (isset($_POST['sdte']))?$_POST['sdte']:''; ?>">
<input type="hidden" name="edte" value="<?php echo (isset($_POST['edte']))?$_POST['edte']:''; ?>">
<a href="output.csv" id="fileDownload" download="output.csv" style="display:none;">Download</a>
</div>



<?php
$sdt = $_POST["sdte"];
$edt = $_POST["edte"];
    if (isset($_POST['download_csv'])) {
//$output=shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export1.sh uat 1am $sdt $edt");
shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export.sh uat 1am $sdt $edt");
//echo "<pre>$output</pre>";
?>
<script type="text/javascript">
var link = document.getElementById('fileDownload');
link.click();
</script>
<?php
    }
?>
</body>
</html>

