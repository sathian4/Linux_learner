<html>
<body>

<form action="v11uat_stat.php" method="post">
Previous Date: <input type="date" name="dte"><br>
<input type="submit">
</form>

</body>
</html>

<div class="row">
<div class="column">
<form action="" method="post">
<input type="submit" name="current_status" value="Current Status">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="completed_status" value="Completed Status">
</div>
</form>
<div class="column">
<form action="" method="post">
<input type="submit" name="running" value="Running Status">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="not_started" value="Not Started">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="error" value="Error">
</form>
</div>
<div class="column">
<form action="" method="post">
<input type="submit" name="home_page" value="Home Page">
</form>
</div>


<?php
$dt = $_POST["name"];
    if (isset($_POST['current_status'])) {
$output=shell_exec('sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 3 1');
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['completed_status'])) {
$output=shell_exec('sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 3 2');
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['running'])) {
$output=shell_exec('sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 3 3 $dt');
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['not_started'])) {
$output=shell_exec('sh /home/sakthi/unica_dash/step3_exec_cur_dashbrd_status.sh 3 4');
echo "<pre>$output</pre>";
    }
    elseif (isset($_POST['error'])) {
$output=shell_exec('sh /home/sakthi/unica_dash/test.sh 3 5 $dt');
echo "<pre>$output</pre>";
    }
elseif (isset($_POST['home_page'])) {
header("Location: http://192.168.0.60/status.html");
    }

?>


