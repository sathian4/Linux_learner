<?php
shell_exec("/bin/bash /home/sakthi/unica_dash/step5_csv_export1.sh uat 1am 2019-07-20 2019-07-21 > /tmp/dinesh.txt");
?>
